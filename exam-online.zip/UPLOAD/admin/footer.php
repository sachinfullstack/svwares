<?php
  if (!defined("_VALID_PHP"))
      die('Direct access to this location is not allowed.');
?>
  <!-- Main Content /-->


  </div>
</div>
</div>

<!-- Footer -->
<footer id="footer" class="clearfix">
  <div class="row">
    <div class="fotter-wrap">
      <div class="col grid_24">
        <div class="copyright">Copyright &copy;<?php echo date('Y').' '.$core->company;?> &bull; Powered by: Exam Board v <?php echo $core->crmv;?></div>
      </div>
    </div>
  </div>
</footer>
<!-- Footer /-->


</div><!-- container /-->
</div><!-- Bg /-->
<!-- The Main Menu Js -->
<script type="text/javascript">
var menu = new cbpHorizontalSlideOutMenu( document.getElementById( 'cbp-hsmenu-wrapper' ) );
</script>
<!-- The Main Menu Js /-->
</body></html>