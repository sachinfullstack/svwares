<div class="inner-content"><a href="install.php">pre-installation check</a> &raquo; <b>license</b> &raquo; configuration &raquo; completed</div>
<h2 id="install"><img src="img/licence.png" alt="" />License Agreement</h2>

<iframe src="license.html" class="license" frameborder="0" scrolling="auto"></iframe>
<div class="btn lgn">
  <button type="button" onclick="document.location.href='install.php';" name="back" tabindex="3">Back</button>
  &nbsp;&nbsp;
  <button type="button" onclick="document.location.href='install.php?step=2';" name="next" tabindex="3">Next</button>
</div>
